import java.util.Scanner;
import java.io.*;
public class FloresElmer_Floyd2 extends FloresElmer_Floyd2Algo {
	
		public static void main(String[]args) throws Exception{
      int[][] matrix = new int[6][6];
      int[][] matrix2 = new int[8][8];
      int[][] matrix3 = new int[10][10];
      
FloresElmer_Floyd2Algo test1 = new FloresElmer_Floyd2Algo();
FloresElmer_Floyd2Algo test2 = new FloresElmer_Floyd2Algo();
FloresElmer_Floyd2Algo test3 = new FloresElmer_Floyd2Algo();
               
         Scanner in;
try {
Scanner s = new Scanner(new File("Elmer_floyd.dat"));
Scanner t = new Scanner(new File("Elmer_floyd2.dat"));
Scanner r = new Scanner(new File("Elmer_floyd3.dat"));



      //test 1 from file
       for (int i = 0; i < matrix.length && s.hasNextLine(); i++) 
       {
         for (int col = 0; col < matrix.length && s.hasNextInt(); col++) 
         {
           matrix[i][col] = s.nextInt() ;

          }
          s.nextLine(); 
        }
          
        //test 2 from file       
        for (int i = 0; i < matrix2.length && t.hasNextLine(); i++) 
        {
           for (int col = 0; col < matrix2.length && t.hasNextInt(); col++)
            {
              matrix2[i][col] = t.nextInt() ;

            }
          t.nextLine(); 
         }
         
           //test 3 from file       
        for (int i = 0; i < matrix3.length && r.hasNextLine(); i++) 
        {
           for (int col = 0; col < matrix3.length && r.hasNextInt(); col++)
            {
              matrix3[i][col] = r.nextInt() ;

         }
          r.nextLine(); 
         }

                
                

            s.close();
            t.close();
            r.close();
            
        
        

        } catch (IOException i) {
            System.out.println("Problems..");

        }
   //Sends cases to Floyd Algo plus timer     
  long start = System.currentTimeMillis();
    //test one with timer
    System.out.println("Test Case one:");       
    test1.floyd2(matrix,6);
   
   long realTime = System.currentTimeMillis()-start;
   System.out.print("Time elapsed in milliseconds: " +  realTime + " ms");
   System.out.println(""); 
    
    //test 2 with timer   
    start = System.currentTimeMillis();
    System.out.println(""); 
   
    System.out.println("Test Case two:"); 
    test2.floyd2(matrix2,8);
    
    realTime = System.currentTimeMillis()-start;
    System.out.print("Time elapsed in milliseconds: " +  realTime + " ms");
	 System.out.println(""); 
 
    //test 3 with timer 
    start = System.currentTimeMillis();
    System.out.println("");   
    System.out.println("Test Case three:"); 
    test3.floyd2(matrix3,10); 
    realTime = System.currentTimeMillis()-start;
    System.out.print("Time elapsed in milliseconds: " +  realTime + " ms");
       
        
 }
        
        
        
        
}
