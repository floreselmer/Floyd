import java.util.*;
import java.lang.*;
import java.io.*;

class FloresElmer_Floyd2Algo
{
	final static int INF = 99999;
   
	void floyd2(int W[][],int n)
	{
		int D[][] = new int[n][n];
		int i, j, k;
      
		for (i = 0; i < n; i++)
			for (j = 0; j < n; j++)
				D[i][j] = W[i][j];
      
		for (k = 0; k < n; k++)
		{
			for (i = 0; i < n; i++)
			{
				for (j = 0; j < n; j++)
				{
					if (D[i][k] + D[k][j] < D[i][j])
						D[i][j] = D[i][k] + D[k][j];
				}
			}
		}
      
		print(D,n);
	}
   
	void print(int D[][],int n)
	{
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
			{
				if (D[i][j]==INF)
					System.out.print("INF ");
				else
					System.out.print(D[i][j]+"   ");
			}
			System.out.println();
		}
	}
} 
